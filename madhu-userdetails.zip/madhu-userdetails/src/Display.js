import React from "react";
import { useParams } from "react-router-dom";

function Display(u) {
  const { id } = useParams();
  // console.log(name)

  const user_detail = [
    {
      id: 1,
      name: "madhu",
      email: "mad12@gmail.com",
    },
    {
      id: 2,
      name: "mitha",
      email: "mit12@gmail.com",
    },
    {
      id: 3,
      name: "anu",
      email: "anu12@gmail.com",
    },
  ];
  

  return (
    <>
    
      {user_detail
        .filter((el) => el.id === parseInt(id))
        .map((element) => 
            // console.log(('name ',element.name));
          <>
            <p>id:{element.id}</p>
            <p>name:{element.name}</p>
            <p>email:{element.email}</p>
          </>
        )}
    </>
  );
}
export default Display;
