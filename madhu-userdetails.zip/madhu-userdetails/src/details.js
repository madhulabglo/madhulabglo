import React from "react";
import {Link, useNavigate} from "react-router-dom"

function Details() {
  const navigate = useNavigate()
  const columns = ["id", "name", "email"];
  const user_detail = [
    {
      id: 1,
      name: "madhu",
      email: "mad12@gmail.com",
    },
    {
      id: 2,
      name: "mitha",
      email: "mit12@gmail.com",
    },
    {
      id: 3,
      name: "anu",
      email: "anu12@gmail.com",
    },
  ];
  function next_page(id){

    navigate(`/Display/${id}`)
    // console.log("id",id)
  }

  

  return (
    <>
      <table border="1">
        <thead>
          
              <tr>
                  <th>{columns[0]}</th>
                  <th>{columns[1]}</th>
                  <th>{columns[2]}</th>
              </tr>
          
        </thead>
        <tbody>
          
            {user_detail.map((el) => {
              return (
                  <tr>
                <td onClick={()=>next_page(el.id)}>{el.id}</td>
                <td>{el.name}</td>
                <td>{el.email}</td>
                </tr>
              );
            })}
         
        </tbody>
      </table>
    </>
  );
}

export default Details;
