import logo from './logo.svg';
import './App.css';
import {Route,Routes} from 'react-router-dom';
import { BrowserRouter as Router  } from 'react-router-dom';


import Details from './details.js';
import Display from './Display.js';


function App() {
  return (
   <>
    <Router>
      <Routes>
        <Route exact path = "/" element = {<Details/>}/>
        <Route exact path = "/display/:id" element = {<Display/>}/>
      </Routes>
    </Router>




   
   </>
  );
}

export default App;
